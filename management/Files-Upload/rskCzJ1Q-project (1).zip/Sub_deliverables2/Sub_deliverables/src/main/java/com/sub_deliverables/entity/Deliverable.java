package com.sub_deliverables.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table
public class Deliverable {

	@Id
	private int did;
	@Column(name = "delivale_name")
	private String dname;

	@OneToMany(targetEntity = SubDeliverable.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "ddid", referencedColumnName = "did")
	private List<SubDeliverable> subDeliverable=new ArrayList<>();

	public Deliverable() {
		super();
	}

	public Deliverable(int did, String dname, List<SubDeliverable> subDeliverable) {
		super();
		this.did = did;
		this.dname = dname;
		this.subDeliverable = subDeliverable;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public List<SubDeliverable> getSubDeliverable() {
		return subDeliverable;
	}

	public void setSubDeliverable(List<SubDeliverable> subDeliverable) {
		this.subDeliverable = subDeliverable;
	}

	@Override
	public String toString() {
		return "Deliverable [did=" + did + ", dname=" + dname + ", subDeliverable=" + subDeliverable + "]";
	}

}