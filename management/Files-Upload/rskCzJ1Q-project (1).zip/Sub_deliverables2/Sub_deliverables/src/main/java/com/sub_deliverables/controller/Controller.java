package com.sub_deliverables.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sub_deliverables.dto.RequestController;
import com.sub_deliverables.entity.Deliverable;
import com.sub_deliverables.repo.DeliverableRepo;
import com.sub_deliverables.repo.SubDeliverableRepo;


@RestController
public class Controller {
	
	@Autowired
	DeliverableRepo deliverableRepo;
	
	@Autowired
	SubDeliverableRepo subDeliverableRepo;
	
	
	//adding subdeliverables to deliverable
	@PostMapping("/deliverables")
	public ResponseEntity<Deliverable> Add(@RequestBody RequestController requestController) {
		return new ResponseEntity(deliverableRepo.save(requestController.getDeliverable()),HttpStatus.CREATED);
	}
	
	//Showing all deliverables
	@GetMapping("/deliverables")
	public ResponseEntity<List<Deliverable>> findalldel(){
		return new ResponseEntity(deliverableRepo.findAll(),HttpStatus.OK);
	}
	
	//showing deliverable with id
	
	@GetMapping("/deliverables/{did}")
	public ResponseEntity<Deliverable> findindel(@PathVariable int did){
		Optional<Deliverable> deliverable=deliverableRepo.findById(did);
		
		if(deliverable.isPresent()) {
			return new ResponseEntity(deliverable.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}	
	}

	//update deliverable
	@PutMapping("/deliverables/{did}")
	public ResponseEntity<Deliverable> updatedel(@PathVariable int did,@RequestBody Deliverable deliverable1){
		Optional<Deliverable> deliverable=deliverableRepo.findById(did);
		if(deliverable.isPresent()) {
			deliverable.get().setDid(deliverable1.getDid());
			deliverable.get().setDname(deliverable1.getDname());
			deliverable.get().setSubDeliverable(deliverable1.getSubDeliverable());
			return new ResponseEntity(deliverableRepo.save(deliverable.get()),HttpStatus.OK);
		}
		else {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}	
	}
	
	//delete deliverable
	@DeleteMapping("/deliverables/{did}")
	public ResponseEntity<Void> delDel(@PathVariable int did){
		Optional<Deliverable> deliverable=deliverableRepo.findById(did);
		
		if(deliverable.isPresent()) {
			deliverableRepo.deleteById(did);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		else {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}	
	}

}
