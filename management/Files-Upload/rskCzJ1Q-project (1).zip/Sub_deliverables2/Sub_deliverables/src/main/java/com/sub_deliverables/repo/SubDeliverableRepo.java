package com.sub_deliverables.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sub_deliverables.entity.SubDeliverable;

public interface SubDeliverableRepo extends JpaRepository<SubDeliverable, Integer> {

}
