package com.sub_deliverables.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class SubDeliverable {

	@Id
	private int sid;
	@Column(name = "subdelname")
	private String sname;

	public SubDeliverable() {
		super();
	}

	public SubDeliverable(int sid, String sname) {
		super();
		this.sid = sid;
		this.sname = sname;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getsname() {
		return sname;
	}

	public void setsname(String sname) {
		this.sname = sname;
	}

	@Override
	public String toString() {
		return "SubDeliverable [Sid=" + sid + ", sname=" + sname + "]";
	}

}