package com.sub_deliverables.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sub_deliverables.entity.Deliverable;

public interface DeliverableRepo  extends JpaRepository<Deliverable, Integer>{

}
