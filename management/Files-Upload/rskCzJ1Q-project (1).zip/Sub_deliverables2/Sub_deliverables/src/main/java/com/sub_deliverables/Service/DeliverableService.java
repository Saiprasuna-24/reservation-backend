package com.sub_deliverables.Service;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import org.springframework.stereotype.Service;

import com.sub_deliverables.entity.Deliverable;


@Service
public class DeliverableService {
	private static List<Deliverable> deliverable;

	public List<Deliverable> retrieveAllDeliverables() {

		return deliverable;
	}
	

}
