package com.sub_deliverables.dto;

import com.sub_deliverables.entity.Deliverable;

public class RequestController {
	
	private Deliverable deliverable;

	public RequestController(Deliverable deliverable) {
		super();
		this.deliverable = deliverable;
	}

	@Override
	public String toString() {
		return "ReqestController [deliverable=" + deliverable + "]";
	}

	public RequestController() {
		super();
	}

	public Deliverable getDeliverable() {
		return deliverable;
	}

	public void setDeliverable(Deliverable deliverable) {
		this.deliverable = deliverable;
	}

}
