package com.sub_deliverables;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubDeliverablesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubDeliverablesApplication.class, args);
	
		}

}
