package com.sub_deliverables;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubDeliverablesApplicationTests {

	@Test
	void contextLoads() {
	}

}
